package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.project.brightvidya.BrightVidya.R;

public class class10_biology_chapters extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class10_biology_chapters);
        Button c1 = (Button) findViewById(R.id.c1);
        Button c2 = (Button) findViewById(R.id.c2);
        c1.setOnClickListener(this);
        c2.setOnClickListener(this);
    }
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.c1:
                Intent t1 = new Intent(class10_biology_chapters.this, class10_biology_chapter1.class);
                startActivity(t1);
                break;
            case R.id.c2:
                Intent t2 = new Intent(class10_biology_chapters.this, class10_biology_chapter2.class);
                startActivity(t2);
                break;
        }

    }
}



