package com.project.brightvidya.BrightVidya;

import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.project.brightvidya.BrightVidya.R;
import com.github.barteksc.pdfviewer.PDFView;


public class papers extends AppCompatActivity {

    TextView tm_en_1,tm_en_2,tm_mat_1,tm_mat_2,tm_sc_1,tm_sc_2,tm_so_1,tm_so_2;
    TextView em_en_1,em_en_2,em_mat_1,em_mat_2,em_sc_1,em_sc_2,em_so_1,em_so_2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_papers);
        //tel
        tm_en_1 = (TextView) findViewById(R.id.tm_en_1);
        tm_en_2 = (TextView) findViewById(R.id.tm_en_2);
        tm_mat_1 = (TextView) findViewById(R.id.tm_mat_1);
        tm_mat_2 = (TextView) findViewById(R.id.tm_mat_2);
        tm_sc_1 = (TextView) findViewById(R.id.tm_sc_1);
        tm_sc_2 = (TextView) findViewById(R.id.tm_sc_2);
        tm_so_1 = (TextView) findViewById(R.id.tm_so_1);
        tm_so_2 = (TextView) findViewById(R.id.tm_so_2);
        //eng
        em_en_1 = (TextView) findViewById(R.id.em_en_1);
        em_en_2 = (TextView) findViewById(R.id.em_en_2);
        em_mat_1 = (TextView) findViewById(R.id.em_mat_1);
        em_mat_2 = (TextView) findViewById(R.id.em_mat_2);
        em_sc_1 = (TextView) findViewById(R.id.em_sc_1);
        em_sc_2 = (TextView) findViewById(R.id.em_sc_2);
        em_so_1 = (TextView) findViewById(R.id.em_so_1);
        em_so_2 = (TextView) findViewById(R.id.em_so_2);

        //if (mLink != null) {
        tm_en_1.setMovementMethod(LinkMovementMethod.getInstance());
        tm_en_2.setMovementMethod(LinkMovementMethod.getInstance());
        tm_mat_1.setMovementMethod(LinkMovementMethod.getInstance());
        tm_mat_2.setMovementMethod(LinkMovementMethod.getInstance());
        tm_sc_1.setMovementMethod(LinkMovementMethod.getInstance());
        tm_sc_2.setMovementMethod(LinkMovementMethod.getInstance());
        tm_so_1.setMovementMethod(LinkMovementMethod.getInstance());
        tm_so_2.setMovementMethod(LinkMovementMethod.getInstance());

        //eng
        em_en_1.setMovementMethod(LinkMovementMethod.getInstance());
        em_en_2.setMovementMethod(LinkMovementMethod.getInstance());
        em_mat_1.setMovementMethod(LinkMovementMethod.getInstance());
        em_mat_2.setMovementMethod(LinkMovementMethod.getInstance());
        em_sc_1.setMovementMethod(LinkMovementMethod.getInstance());
        em_sc_2.setMovementMethod(LinkMovementMethod.getInstance());
        em_so_1.setMovementMethod(LinkMovementMethod.getInstance());
        em_so_2.setMovementMethod(LinkMovementMethod.getInstance());

    }
}