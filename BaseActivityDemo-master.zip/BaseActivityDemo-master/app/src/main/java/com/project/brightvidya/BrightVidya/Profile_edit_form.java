package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static com.project.brightvidya.BrightVidya.HomeActivity.MyPREFERENCES;
import static com.project.brightvidya.BrightVidya.HomeActivity.Student_name;
import static com.project.brightvidya.BrightVidya.HomeActivity.s;

public class Profile_edit_form extends AppCompatActivity {

    private TextView change_name;
     Button SAVE;
    private SharedPreferences sharedpreferences;
    private String edit_name;
    private TextView welcome_whish;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_edit_form);
        SAVE=(Button)findViewById(R.id.SAVE);
        change_name = (TextView) findViewById(R.id.change_name_textview);
        welcome_whish=(TextView)findViewById(R.id.welcome_whish);
        sharedpreferences = getApplicationContext().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
     //   edit_name = sharedpreferences.getString("name","");
        SAVE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences.Editor editor = sharedpreferences.edit();
                s = change_name.getText().toString();
                editor.putString("Change_name", s);
                editor.commit();
                welcome_whish.setText("Hello " + change_name.getText().toString());
                Toast.makeText(getApplicationContext(),"Success", Toast.LENGTH_SHORT).show();
                Intent intent;
                intent = new Intent(Profile_edit_form.this, HomeActivity.class);
                startActivity(intent);
        }
        });
    }
}