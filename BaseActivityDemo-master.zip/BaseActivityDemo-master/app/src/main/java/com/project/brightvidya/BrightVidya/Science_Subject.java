package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.firebase.database.DatabaseReference;

public class Science_Subject extends AppCompatActivity {
String C1,C2,C3,C4,C5;
CardView card1,card2,card3,card4,card5;
    private TextView Chapter_1,Chapter_2,Chapter_3,Chapter_4,Chapter_5;
  ImageView back_button;
    private DatabaseReference rootRef,demoRef1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        setContentView(R.layout.activity_science__subject);
        card1=(CardView) findViewById(R.id.chapter1_card);
        card2=(CardView) findViewById(R.id.chapter2_card);
        card3=(CardView) findViewById(R.id.chapter3_card);
        card4=(CardView) findViewById(R.id.chapter4_card);
        card5=(CardView) findViewById(R.id.chapter5_card);
       Chapter_1=(TextView) findViewById(R.id.chapter1_title);
        Chapter_2=(TextView) findViewById(R.id.chapter2_title);
        Chapter_3=(TextView) findViewById(R.id.chapter3_title);
        Chapter_4=(TextView) findViewById(R.id.chapter4_title);
        Chapter_5=(TextView) findViewById(R.id.chapter5_title);
        ImageView back_button=(ImageView)findViewById(R.id.back_image);
        Bundle gt=getIntent().getExtras();
        C1=gt.getString("c1");
        C2=gt.getString("c2");
        C3=gt.getString("c3");
        C4=gt.getString("c4");
        C5=gt.getString("c5");
        Chapter_1.setText(C1);Chapter_2.setText(C2);
        Chapter_3.setText(C3);Chapter_4.setText(C4);Chapter_5.setText(C5);

        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Science_Subject.this, HomeActivity.class);
                startActivity(i);
            }
        });
    }
}