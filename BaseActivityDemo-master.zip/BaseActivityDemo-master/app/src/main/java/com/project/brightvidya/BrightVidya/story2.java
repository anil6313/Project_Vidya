package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.project.brightvidya.BrightVidya.R;

public class story2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story2);
    }
}
