package com.project.brightvidya.BrightVidya;

import android.os.Bundle;
import android.view.View;

import com.project.brightvidya.BrightVidya.R;

public abstract  class live_classes extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View rootView = getLayoutInflater().inflate(R.layout.activity_gallery, frameLayout);
        txt_menuTitle.setText("Live Classes");
    }
}
