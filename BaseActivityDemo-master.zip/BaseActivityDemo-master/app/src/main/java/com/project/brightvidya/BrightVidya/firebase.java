package com.project.brightvidya.BrightVidya;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class firebase extends AppCompatActivity implements View.OnClickListener {

    EditText editText;
    Button submit;
    private DatabaseReference rootRef, demoRef1,demoRef2;
    String Id;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firebase);

        Button fetchButton1 = findViewById(R.id.btnFetch1);
        fetchButton1.setOnClickListener(this);
        Button fetchButton2 = findViewById(R.id.btnFetch2);
          fetchButton2.setOnClickListener(this);
         TextView fetchedText = findViewById(R.id.tvValue);
        rootRef = FirebaseDatabase.getInstance().getReference();
        // Database reference pointing to demo node
        demoRef1 = rootRef.child("demo1");
        demoRef2 = rootRef.child("demo2");
    }
    public void onClick(View v) {
        switch(v.getId())
        {
            case R.id.btnFetch1:
                demoRef1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Id = dataSnapshot.getValue(String.class);
                        String s=Id;
                        Bundle basket= new Bundle();
                        basket.putString("abc", s);
                        Intent a=new Intent(firebase.this,topics.class);
                        a.putExtras(basket);
                        startActivity(a);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(firebase.this, "Error fetching data", Toast.LENGTH_LONG).show();
                    }
                });
                break;
            case R.id.btnFetch2:
                demoRef2.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Id = dataSnapshot.getValue(String.class);
                        String s=Id;
                        Bundle basket= new Bundle();
                        basket.putString("abc", s);
                        Intent a=new Intent(firebase.this,topics.class);
                        a.putExtras(basket);
                        startActivity(a);
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(firebase.this, "Error fetching data", Toast.LENGTH_LONG).show();
                    }
                });
                break;
                default:
                    throw new RuntimeException("Unknow button ID");
            }


    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}