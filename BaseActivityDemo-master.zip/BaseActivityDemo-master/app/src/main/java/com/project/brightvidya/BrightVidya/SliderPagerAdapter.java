package com.project.brightvidya.BrightVidya;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class SliderPagerAdapter extends FragmentPagerAdapter {
  public SliderPagerAdapter(@androidx.annotation.NonNull FragmentManager fm, int behavior) {
    super(fm, behavior);
  }

  @androidx.annotation.NonNull
  @Override public Fragment getItem(int position) {
    return SliderItemFragment.newInstance(position);
  }

  @Override public int getCount() {
    return 3;
  }
}