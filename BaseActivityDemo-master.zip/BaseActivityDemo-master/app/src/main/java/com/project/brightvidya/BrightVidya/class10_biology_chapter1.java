package com.project.brightvidya.BrightVidya;

import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.project.brightvidya.BrightVidya.R;
import com.google.android.material.tabs.TabLayout;

public class class10_biology_chapter1 extends AppCompatActivity implements classs_10_biology_chapter1_topic1.OnFragmentInteractionListener,
        classs_10_biology_chapter1_topic2.OnFragmentInteractionListener,classs_10_biology_chapter1_topic3.OnFragmentInteractionListener,
        classs_10_biology_chapter1_topic4.OnFragmentInteractionListener,classs_10_biology_chapter1_topic5.OnFragmentInteractionListener {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.class10_biology_chapter1);
            TabLayout tabLayout = (TabLayout)findViewById(R.id.tablayout);
            tabLayout.addTab(tabLayout.newTab().setText("T1"));
            tabLayout.addTab(tabLayout.newTab().setText("T2"));
            tabLayout.addTab(tabLayout.newTab().setText("T3"));
            tabLayout.addTab(tabLayout.newTab().setText("T4"));
            tabLayout.addTab(tabLayout.newTab().setText("T5"));

            tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

            final ViewPager viewPager;
            viewPager = (ViewPager)findViewById(R.id.pager);
             PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(),tabLayout.getTabCount());
            viewPager.setAdapter(adapter);
            viewPager.setOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

            tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {
                    viewPager.setCurrentItem(tab.getPosition());
                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {

                }
            });

        }

        @Override
        public void onFragmentInteraction(Uri uri) {

        }

    public class PagerAdapter extends FragmentStatePagerAdapter {

        int mNoOfTabs;

        public PagerAdapter(FragmentManager fm, int NumberOfTabs)
        {
            super(fm);
            this.mNoOfTabs = NumberOfTabs;
        }


        @Override
        public Fragment getItem(int position) {
            switch(position)
            {

                case 0:
                    classs_10_biology_chapter1_topic1 tab1 = new classs_10_biology_chapter1_topic1();
                    return tab1;
                case 1:
                    classs_10_biology_chapter1_topic2 tab2 = new classs_10_biology_chapter1_topic2();
                    return  tab2;
                case 2:
                    classs_10_biology_chapter1_topic3 tab3 = new classs_10_biology_chapter1_topic3();
                    return  tab3;
                case 3:
                    classs_10_biology_chapter1_topic4 tab4 = new classs_10_biology_chapter1_topic4();
                    return  tab4;
                case 4:
                    classs_10_biology_chapter1_topic5 tab5 = new classs_10_biology_chapter1_topic5();
                    return  tab5;
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return mNoOfTabs;
        }
    }

    }