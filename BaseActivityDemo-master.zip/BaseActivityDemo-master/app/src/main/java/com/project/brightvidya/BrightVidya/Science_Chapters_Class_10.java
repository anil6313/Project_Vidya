package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

public class Science_Chapters_Class_10 extends AppCompatActivity {
    EditText name;
    String Science_10;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_science__chapters__class_10);
        name = (EditText) findViewById(R.id.student_name);

        Bundle gt=getIntent().getExtras();
        String Science_10=gt.getString("abc");

    }
}