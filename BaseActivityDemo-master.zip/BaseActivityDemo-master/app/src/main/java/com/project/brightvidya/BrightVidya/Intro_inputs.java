package com.project.brightvidya.BrightVidya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextPaint;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.lang.reflect.Field;

import static com.project.brightvidya.BrightVidya.HomeActivity.Student_class;
import static com.project.brightvidya.BrightVidya.HomeActivity.f;
import static com.project.brightvidya.BrightVidya.HomeActivity.s;

public class Intro_inputs extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    Button next_button;
    SharedPreferences prefs;
    boolean firstStart;
    EditText name;
    public Spinner sp;
    public int Classvalue;
    ImageView App_logo;
    String class_string;
    Animation shake;
    public int class_Store,name_store;
     SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro_inputs);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        next_button = (Button) findViewById(R.id.next_button);
        TextView title = (TextView) findViewById(R.id.Title);
        EditText student_name=(EditText)findViewById(R.id.student_name);
        TextPaint paint2 = title.getPaint();

        float width2 = paint2.measureText("Tianjin, China");
        Shader textShader2= new LinearGradient(0, 0, width2, student_name.getTextSize(),
                new int[]{
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),
                }, null, Shader.TileMode.CLAMP);
        student_name.getPaint().setShader(textShader2);

        TextPaint paint1 = student_name.getPaint();
        float width1 = paint1.measureText("Tianjin, China");
        Shader textShader1= new LinearGradient(0, 0, width1, title.getTextSize(),
                new int[]{
                        Color.parseColor("#F97C3C"),
                        Color.parseColor("#FDB54E"),
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),
                }, null, Shader.TileMode.CLAMP);
        title.getPaint().setShader(textShader1);
        App_logo=(ImageView)findViewById(R.id.logo);
        name = (EditText) findViewById(R.id.student_name);
        final MaterialSpinner spinner = (MaterialSpinner) findViewById(R.id.spinner);
        spinner.setItems("Choose Class","Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10");
        next_button.setOnClickListener(this);
        shake = AnimationUtils.loadAnimation(this, R.anim.shake);
        name.startAnimation(shake);
        spinner.startAnimation(shake);
        sharedpreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                class_string=spinner.getText().toString();
                String item_position = String.valueOf(position);
                Classvalue = Integer.valueOf(item_position); if (Classvalue!=0){
                Snackbar.make(view, "You have Selected " + item, Snackbar.LENGTH_LONG).show();}

            }
        });
        next_button.setOnClickListener(new View.OnClickListener() {

            @Override public void onClick(View view) {
                String error_name = name.getText().toString().trim();
                if (!error_name.matches("[a-zA-Z ]+"))
                {
                    name.setError("Enter only alphabetic characters");
                    name.requestFocus();
                }
                else if(Classvalue==0)
                {
                    spinner.startAnimation(shake);
                 }
                else
                {
                    s = name.getText().toString();
                    class_Store = Classvalue;
                    SharedPreferences.Editor editor = sharedpreferences.edit();
                    editor.putString("name", s);
                    editor.putInt("Classvalue", class_Store);
                    editor.commit();
                    Intent i1 = new Intent(Intro_inputs.this, HomeActivity.class);
                    startActivity(i1);}
            }});
    }



    @Override
    public void onClick(View view) {
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }
}