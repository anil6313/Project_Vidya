package com.project.brightvidya.BrightVidya;
import android.accessibilityservice.AccessibilityService;
import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextPaint;
import android.view.Display;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.cardview.widget.CardView;

import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.HashMap;
import java.util.jar.Attributes;

import static android.provider.ContactsContract.ProviderStatus.STATUS;

public class HomeActivity extends BaseActivity implements View.OnClickListener {
    private static final String TAG = "HomeActivity";
    private String Classvalue;
    private  int store_class;
    Dialog myDialog;
    ImageButton Telugu;
    TextView txtclose;
    boolean firstStart1;
    public static TextView welcome,Class;
    private TextView Science;
    String chapter_1,chapter_2,chapter_3,chapter_4,chapter_5;
    public static String Student_name;
    public static String Student_class;
    private DatabaseReference dref;SharedPreferences sharedpreferences;
    public static final String MyPREFERENCES = "MyPrefs" ;
   public static  String s,f;
   Button edit;
   public final String SAVED_TEXT = "saved_text";

    EditText person_name;
    private EditText Name;
    private AccessibilityService getContext;
    private String def_Pos;
    private Integer posit;
    private Animation shake;

    //   private ImageView menu_option;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    //    requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);
      //  getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        //setContentView(R.layout.activity_home);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
       View rootView = getLayoutInflater().inflate(R.layout.activity_home, frameLayout);
        LinearLayout i = (LinearLayout) findViewById(R.id.l1);
        i.setAlpha((float) 1.0);
        welcome = (TextView) findViewById(R.id.welcome_whish);
        TextView play_quiz = (TextView) findViewById(R.id.play_quiz);
        TextPaint paint1 = welcome.getPaint();

        float width1 = paint1.measureText("Tianjin, China");
        Shader textShader1 = new LinearGradient(0, 0, width1, welcome.getTextSize(),
                new int[]{
                        Color.parseColor("#F97C3C"),
                        Color.parseColor("#FDB54E"),
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),
                }, null, Shader.TileMode.CLAMP);
        welcome.getPaint().setShader(textShader1);
        TextPaint paint2 = play_quiz.getPaint();

        float width2 = paint2.measureText("Tianjin, China");
        Shader textShader2= new LinearGradient(0, 0, width2, play_quiz.getTextSize(),
                new int[]{
                        Color.parseColor("#F97C3C"),
                        Color.parseColor("#FDB54E"),
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),
                }, null, Shader.TileMode.CLAMP);
        play_quiz.getPaint().setShader(textShader2);
        Name= (EditText) findViewById(R.id.student_name);
        shake = AnimationUtils.loadAnimation(this, R.anim.shake);
        final MaterialSpinner spinner = (MaterialSpinner) findViewById(R.id.spinner);
        TextPaint paint = spinner.getPaint();
        float width = paint.measureText("Tianjin, China");
        Shader textShader = new LinearGradient(0, 0, width, spinner.getTextSize(),
                new int[]{
                        Color.parseColor("#5ca2db"),
                        Color.parseColor("#c19adb"),
                        Color.parseColor("#c282b3"),
                        Color.parseColor("#F97C3C"),
                        Color.parseColor("#FDB54E"),
                        Color.parseColor("#64B678"),
                        Color.parseColor("#478AEA"),
                        Color.parseColor("#8446CC"),

                }, null, Shader.TileMode.CLAMP);
        spinner.getPaint().setShader(textShader);

        spinner.setItems("Choose Class","Class 1","Class 2","Class 3","Class 4","Class 5","Class 6","Class 7","Class 8","Class 9","Class 10");
        Science = (TextView) findViewById(R.id.Science_Subject);
        sharedpreferences = getApplicationContext().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        s = sharedpreferences.getString("name","");
        store_class = sharedpreferences.getInt("Classvalue", 0);
        spinner.setSelectedIndex(store_class);
        Classvalue = spinner.getText().toString();
        Calendar c = Calendar.getInstance();
        int timeOfDay = c.get(Calendar.HOUR_OF_DAY);

        if(timeOfDay >= 0 && timeOfDay < 12){
            welcome.setText("Good Morning " +s);
        }else if(timeOfDay >= 12 && timeOfDay < 16){
            welcome.setText("Good afternoon " +s);
        }else if(timeOfDay >= 16 && timeOfDay < 21){
            welcome.setText("Good Evening " +s);
        }else if(timeOfDay >= 21 && timeOfDay < 24){
            welcome.setText("Good Night " +s);
        }
        CardView science_card = (CardView) findViewById(R.id.Science_subject);
        CardView maths_card = (CardView) findViewById(R.id.maths_subject);
        CardView social_card = (CardView) findViewById(R.id.social_subject);
        CardView gk_card = (CardView) findViewById(R.id.gk_subject);
        dref = FirebaseDatabase.getInstance().getReference();
        dref = dref.child("Science");
        dref= FirebaseDatabase.getInstance().getReference();


        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override public void onItemSelected(MaterialSpinner view, int position, long id, String item) {

                Classvalue = spinner.getText().toString();
                String item_position = String.valueOf(position);
                posit = Integer.valueOf(item_position);
                if (posit!=0){
                    Snackbar.make(view, "You have Selected " + item, Snackbar.LENGTH_LONG).show();
                }
            }
        });

        // menu_opti
        science_card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                switch (view.getId()) {
                    case R.id.Science_subject:
                        if (Classvalue.equals("Choose Class")){
                            spinner.startAnimation(shake);
                            Snackbar.make(view, "Please Choose Class" , Snackbar.LENGTH_LONG).show();
                        }
                        else if(Classvalue!=null && Classvalue.equals("Class 10"))
                        { dref.addValueEventListener(new ValueEventListener() {
                            @Override public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot child1 : dataSnapshot.getChildren()) {
                                    HashMap<String, String> value = (HashMap<String, String>) child1.getValue();
                                    chapter_1 = child1.child("Science_Class_10_Chapter_1").getValue(String.class);
                                    chapter_2 = child1.child("Science_Class_10_Chapter_2").getValue(String.class);
                                    chapter_3 = child1.child("Science_Class_10_Chapter_3").getValue(String.class);
                                    chapter_4 = child1.child("Science_Class_10_Chapter_4").getValue(String.class);
                                    chapter_5 = child1.child("Science_Class_10_Chapter_5").getValue(String.class);
                                    String s1 = chapter_1;
                                    String s3 = chapter_3;
                                    String s2 = chapter_2;
                                    String s4 = chapter_4;
                                    String s5 = chapter_5;
                                    Bundle basket1 = new Bundle();
                                    Bundle basket2 = new Bundle();
                                    Bundle basket3 = new Bundle();
                                    Bundle basket4 = new Bundle();
                                    Bundle basket5 = new Bundle();
                                    basket1.putString("c1", s1);
                                    basket3.putString("c3", s3);
                                    basket2.putString("c2", s2);
                                    basket4.putString("c4", s4);
                                    basket5.putString("c5", s5);
                                    Intent i1 = new Intent(HomeActivity.this, Science_Subject.class);
                                    i1.putExtras(basket1);
                                    i1.putExtras(basket3);
                                    i1.putExtras(basket2);
                                    i1.putExtras(basket4);
                                    i1.putExtras(basket5);
                                    startActivity(i1);
                                }
                            }

                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        }); }
                        else if(Classvalue.equals("Class 9"))
                        {  Snackbar.make(view, "You have Selected " + Classvalue, Snackbar.LENGTH_LONG).show();
                            dref.addValueEventListener(new ValueEventListener() {
                            @Override public void onDataChange(DataSnapshot dataSnapshot) {
                                for (DataSnapshot child : dataSnapshot.getChildren()) {
                                    HashMap<String, String> value = (HashMap<String, String>) child.getValue();
                                    chapter_1 = child.child("Science_Class_9_Chapter_1").getValue(String.class);
                                    chapter_2 = child.child("Science_Class_9_Chapter_2").getValue(String.class);
                                    chapter_3 = child.child("Science_Class_9_Chapter_3").getValue(String.class);
                                    chapter_4 = child.child("Science_Class_9_Chapter_4").getValue(String.class);
                                    chapter_5 = child.child("Science_Class_9_Chapter_5").getValue(String.class);
                                    String s1 = chapter_1;
                                    String s3 = chapter_3;
                                    String s2 = chapter_2;
                                    String s4 = chapter_4;
                                    String s5 = chapter_5;
                                    Bundle basket1 = new Bundle();
                                    Bundle basket2 = new Bundle();
                                    Bundle basket3 = new Bundle();
                                    Bundle basket4 = new Bundle();
                                    Bundle basket5 = new Bundle();
                                    basket1.putString("c1", s1);basket2.putString("c2", s2);
                                    basket3.putString("c3", s3);

                                    basket4.putString("c4", s4);
                                    basket5.putString("c5", s5);
                                    Intent i1 = new Intent(HomeActivity.this, Science_Subject.class);
                                    i1.putExtras(basket1);
                                    i1.putExtras(basket3);
                                    i1.putExtras(basket2);
                                    i1.putExtras(basket4);
                                    i1.putExtras(basket5);
                                    startActivity(i1);
                                }
                            }


                            @Override
                            public void onCancelled(DatabaseError databaseError) {

                            }
                        });}
                          else { }

                } }});
                }

    @Override
    public void getWindowVisibleDisplayFrame(Rect r) {

    }


    private void popup() {
        myDialog = new Dialog(this);
        myDialog.setContentView(R.layout.pop);
        txtclose = (TextView) myDialog.findViewById(R.id.txtclose);
        txtclose.setText("X");
        txtclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myDialog.dismiss();
            }
        });
        myDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        myDialog.show();
    }
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
    @Override
    public void onClick(View view) {

    }
}